package com.example.pilltrackerapp2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.WindowDecorActionBar;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.time.LocalDateTime;
import java.time.LocalTime;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.widget.Button;
import android.widget.DatePicker;

import java.time.temporal.ChronoUnit;
import java.util.Calendar;

import android.app.TimePickerDialog;
import android.widget.TimePicker;
import java.util.*;
import java.time.*;
import com.example.pilltrackerapp2.CalendarUtils.*;

import java.util.Locale;

public class EventEditActivity extends AppCompatActivity {
    private static final String TAG = "EventEditActivity";
    private EditText eventNameET;
    private DatePickerDialog datePickerDialog;
    int hour, minute;
    private Button startingDate, timeButton;
    private Button choice;
    private LocalDate startDate, endDate;

    private TextView message;

    private LocalTime time;
    private EditText dosageET;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_edit);
        Log.i(TAG, "Activity created");
        initWidgets();
        initDatePicker();
        time = LocalTime.now();
        Log.i(TAG, "Current time set to: " + time);
    }

    private void initWidgets() {
        eventNameET = findViewById(R.id.eventNameET);
        startingDate = findViewById(R.id.startingDate);
        timeButton = findViewById(R.id.timeButton);
        choice = findViewById(R.id.startingDate);
        message = findViewById(R.id.message);
        dosageET = findViewById(R.id.dosageET);
        Log.i(TAG, "Widgets initialized");
    }

    private void initDatePicker() {
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;
                String date = makeDateString(day, month, year);
                Log.i(TAG, "Date selected: " + date);
                if(choice == startingDate) {
                    startDate = LocalDate.of(year, month, day);
                    Log.i(TAG, "Start date set: " + startDate);
                } else {
                    endDate = LocalDate.of(year, month, day);
                    Log.i(TAG, "End date set: " + endDate);
                }

                choice.setText(date);
            }
        };

        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        int style = AlertDialog.THEME_HOLO_LIGHT;

        datePickerDialog = new DatePickerDialog(this, style, dateSetListener, year, month, day);
        Log.i(TAG, "DatePickerDialog initialized");
    }

    public void popTimePicker(View view) {
        TimePickerDialog.OnTimeSetListener onTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                hour = selectedHour;
                minute = selectedMinute;
                timeButton.setText(String.format(Locale.getDefault(), "%02d:%02d", hour, minute));
                Log.i(TAG, "Time set: " + hour + ":" + minute);
            }
        };

        int style = AlertDialog.THEME_HOLO_DARK;

        TimePickerDialog timePickerDialog = new TimePickerDialog(this, style, onTimeSetListener, hour, minute, true);

        timePickerDialog.setTitle("Select Time");
        timePickerDialog.show();
        Log.i(TAG, "TimePickerDialog shown");
    }

    public void openDatePicker(View view) {
        datePickerDialog.show();
        choice = (Button) view;
        Log.i(TAG, "DatePickerDialog opened");
    }

    private String makeDateString(int day, int month, int year) {
        return getMonthFormat(month) + " " + day + " " + year;
    }

    private String getMonthFormat(int month) {
        String monthString;
        switch (month) {
            case 1: monthString = "JAN"; break;
            case 2: monthString = "FEB"; break;
            case 3: monthString = "MAR"; break;
            case 4: monthString = "APR"; break;
            case 5: monthString = "MAY"; break;
            case 6: monthString = "JUN"; break;
            case 7: monthString = "JUL"; break;
            case 8: monthString = "AUG"; break;
            case 9: monthString = "SEP"; break;
            case 10: monthString = "OCT"; break;
            case 11: monthString = "NOV"; break;
            case 12: monthString = "DEC"; break;
            default: monthString = "JAN"; break; // Default case should never happen
        }
        return monthString;
    }

    public void saveEventAction(View view) {
            //getting part
            String eventName = eventNameET.getText().toString();
            String dosage = dosageET.getText().toString();
            Log.i(TAG, "Event name: " + eventName);
            Pill newPill = new Pill(eventName, dosage);
            LocalTime time = LocalTime.of(hour, minute);

            //adding part
            if (startDate != null && endDate != null && newPill.filled() && !timeButton.getText().equals("Select Time")) {
            CalendarUtils.pillSet.add(newPill);
            Log.i(TAG, "New Pill added: " + newPill.getName());
            long daysBetween = ChronoUnit.DAYS.between(startDate, endDate);
            Log.i(TAG, "Days between start and end date: " + daysBetween);

            for (int i = 0; i <= daysBetween; i++) {
                LocalDateTime starting = LocalDateTime.of(startDate, time);
                if(!CalendarUtils.timeSchedule.containsKey(starting.plusDays(i)))
                {
                    CalendarUtils.timeSchedule.put(starting.plusDays(i), new HashSet<>());
                }
                CalendarUtils.timeSchedule.get(starting.plusDays(i)).add(newPill);
                Log.i(TAG, "Added time to schedule: " + starting.plusDays(i));

            }
            message.setText("");
            CalendarUtils calendarUtils = new CalendarUtils(getApplicationContext());
            calendarUtils.save();
            finish();
            } else {
                Log.e(TAG, "Start or end date is null. Cannot save event.");
                message.setText("You need to fill out the information");
            }




    }
}
package com.example.pilltrackerapp2;

import static androidx.core.content.ContextCompat.startActivity;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import com.example.pilltrackerapp2.CalendarUtils.*;
import static com.example.pilltrackerapp2.WeekViewActivity.deleteMode;
//import com.example.pilltrackerapp2.WeekViewActivity.reload;
public class EventAdapter extends ArrayAdapter<Pill>
{

    public EventAdapter(@NonNull Context context, List<Pill> pills)
    {
        super(context, 0, pills);
        Log.i("gettt", "eventAdapt");
        Log.i("EventAdapter", "Number of pills: " + pills.size());
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent)
    {
        Log.i("gettt", "getview");
        Pill pill = getItem(position);
        Map<LocalDateTime, Set<Pill>> todayTimes = CalendarUtils.getTimesForDay(CalendarUtils.selectedDate);
        TreeSet<LocalDateTime> times = CalendarUtils.getTimeForPill(pill, todayTimes);
        String timesInString = "";
        for(LocalDateTime time: times)
        {

            LocalTime hourTime = time.toLocalTime();
            timesInString +=  CalendarUtils.formattedTime(hourTime) + " ";
        }

        if (convertView == null)
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.event_cell, parent, false);

        TextView eventCellTV = convertView.findViewById(R.id.eventCellTV);
        TextView otherTV = convertView.findViewById(R.id.otherTV);
        String eventName;
        String eventDosage ="Take " + pill.getDosage() + " at " + timesInString;
        if(deleteMode)
        {
            eventName = "Delete " + pill.getName();
            eventDosage = "";
        }
        else
        {
            eventName = pill.getName();
        }

        eventCellTV.setText(eventName);
        otherTV.setText(eventDosage);

        eventCellTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(deleteMode)
                {
                    Log.i("buttonPress", eventCellTV.getText().toString());
                    //work on delete!
                    String title = eventCellTV.getText().toString();
                    String name = title.substring(7);
                    Log.i("helpa", "before context");
                    Context context = getContext().getApplicationContext();
                    CalendarUtils calendarUtils = new CalendarUtils(context);
                    Log.i("helpa", "after context");
                    calendarUtils.deletePill(name);
                    Log.i("helpa", "Context is: " + context);

                }

            }
        });

        return convertView;
    }

}

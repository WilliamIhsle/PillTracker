package com.example.pilltrackerapp2;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public class Pill
{
    private String name;



    private String dosage;

    public Pill(String name, String dosage)
    {
        this.name = name;
        this.dosage = dosage;
    }

    public Pill()
    {}

    public String getName()
    {
        return name;
    }

    public String getDosage() {return dosage;}

    public void setDosage(String dosage) {
        this.dosage = dosage;
    }
    public void setName(String name)
    {
        this.name = name;
    }

    public boolean filled()
    {
        return !(name.isEmpty() || dosage.isEmpty());
    }

}
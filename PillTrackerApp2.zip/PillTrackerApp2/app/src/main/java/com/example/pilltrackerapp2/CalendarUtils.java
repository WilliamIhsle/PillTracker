package com.example.pilltrackerapp2;

import static android.content.Context.MODE_PRIVATE;

import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.*;
import android.content.Context;

public class CalendarUtils
{
    private static boolean hasRun = false;
    private static final String PREFS_NAME = "MyPrefso";
    private static final String KEY_STRING = "myStringo";
    public static LocalDate selectedDate;
    public Context contextl;

    public static Map<LocalDateTime, Set<Pill>> timeSchedule = new TreeMap<>();
    static Set<Pill> pillSet = new HashSet<>();

    String testName;

    public CalendarUtils(Context context)
    {
        contextl = context;
    }
    public static String formattedDate(LocalDate date)
    {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMMM yyyy");
        return date.format(formatter);
    }

    public void save() {
        SharedPreferences sharedPreferences = contextl.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String value = "";
        for(Pill pill: pillSet)
        {
            String line = pill.getName() + ";" + pill.getDosage() + ";";
            for(LocalDateTime time: timeSchedule.keySet()) {
                if (timeSchedule.get(time).contains(pill)) {
                    line += time.toString() + ";";
                }
            }
            value += line +"$";
        }
        Log.i("value",value);
        editor.putString(KEY_STRING, value);
        editor.apply();
    }

    private static String nextPart(String line)
    {
        if (line.indexOf(";") != -1)
        {
            return line.substring(0, line.indexOf(";"));
        }
        return line;

    }

    // Behavior:
    // - removes the first section of line (a section is divided by ;)
    // Parameters:
    // - line: a line from the file
    // Return:
    //  - String: returns the line without the first section
    private static String removePart(String line)
    {
        if(line.indexOf(";") != -1)
        {
            return line.substring(line.indexOf(";") + 1);
        }
        return "";

    }


    public void load() {
        Log.i("10/23", "a");
        if(!hasRun)
        {
            //  SharedPreferences sharedPreferencess = context.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            // SharedPreferences.Editor editor = sharedPreferencess.edit();
            // editor.putString(KEY_STRING, "");
            hasRun = true;
            SharedPreferences sharedPreferences = contextl.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            Log.i("10/20", "now");
            String fullLine = sharedPreferences.getString(KEY_STRING, "");
            Log.i("10/22", fullLine);
            while(!fullLine.isEmpty())
            {
                String line = nextLine(fullLine);
                Log.i("10/21", "a" + removeNextLine(fullLine));
                fullLine = removeNextLine(fullLine);
                Log.i("10/20", "Full line" + fullLine);
                Log.i("10/20", "line" + line);
                String name = nextPart(line);
                line = removePart(line);
                Log.i("10/20", "line" + line);
                String amount = nextPart(line);
                line = removePart(line);
                Log.i("10/20", "line" + line);
                Pill pill = new Pill(name, amount);
                pillSet.add(pill);
                while(!line.isEmpty())
                {
                    Log.i("10/20", "Line isn't empty");
                    Log.i("10/20", "next part " + nextPart(line));
                    LocalDateTime t = LocalDateTime.parse(nextPart(line) + ":00");

                    Log.i("10/20", "t: " + t);
                    line = removePart(line);
                    Log.i("10/20", "line" + line);
                    addPair(pill, t);
                    Log.i("10/20", "added" + t);
                }
            }
        }



    }

    public static String nextLine(String fullLine)
    {
        return fullLine.substring(0, fullLine.indexOf("$"));
    }
    public static String removeNextLine(String line)
    {
        if(line.indexOf("$") != -1)
        {
            return line.substring(line.indexOf("$") + 1);
        }
        return "";
    }

    public static void addPair(Pill pill, LocalDateTime time)
    {
        if(!timeSchedule.containsKey(time))
        {
            timeSchedule.put(time, new HashSet<>());
        }
        timeSchedule.get(time).add(pill);
    }

    public void deletePill(String pillName) {
        if (!(timeSchedule.keySet().isEmpty() || pillSet.isEmpty())) {

            Log.i("deletes", pillName + " uh oh" + timeSchedule.keySet().isEmpty() + pillSet.isEmpty());

            Pill pill = new Pill();
            pill = getPill(pillName);
            while (containsName(pillName)) {
                pill = getPill(pillName);
                pillSet.remove(pill);
                Iterator<LocalDateTime> timeScheduleKeySetItr = timeSchedule.keySet().iterator();
                while (timeScheduleKeySetItr.hasNext()) {
                    LocalDateTime time = timeScheduleKeySetItr.next();
                    Set<Pill> pills = timeSchedule.get(time);
                    if (pills.contains(pill)) {
                        pills.remove(pill);
                        if (pills.isEmpty()) {
                            timeScheduleKeySetItr.remove();
                        }
                    }
                }
            }
            save();
            try {
                Intent intent = new Intent(contextl, WeekViewActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                contextl.startActivity(intent);
            } catch (Exception e) {
                Log.e("helpal", "Error starting activity: " + e.getMessage());
            }
        }
    }


    public static String formattedTime(LocalTime time)
    {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm a");
        return time.format(formatter);
    }
    //gets the pill
    public static Pill getPill(String pillName)
    {
        for (Pill curPill: pillSet)
        {
            if(pillName.equals(curPill.getName()))
            {
                return curPill;
            }
        }
        return new Pill();
    }

    public static ArrayList<Pill> getPillsForDay(LocalDate date)
    {
        Map<LocalDateTime, Set<Pill>> todayPills = getTimesForDay(date);
        Log.i("EventAdapter", "Number of pill" + todayPills.size());
        ArrayList<Pill> dailyPills = new ArrayList<>();
        for(LocalDateTime time: todayPills.keySet())
        {
            Set<Pill> pills = todayPills.get(time);
            for(Pill pill: pills)
            {
                if(!dailyPills.contains(pill))
                {
                    dailyPills.add(pill);
                }
            }

        }
        return dailyPills;
    }

    //get the times for a pill within a scope
    public static TreeSet<LocalDateTime> getTimeForPill(Pill pill, Map<LocalDateTime, Set<Pill>> scope)
    {
        TreeSet<LocalDateTime> times = new TreeSet<>();
        for(LocalDateTime time: scope.keySet())
        {

            if(scope.get(time).contains(pill))
            {
                times.add(time);
            }
        }
        return times;
    }
    //gets a map for specifcally for the day entered
    public static Map<LocalDateTime, Set<Pill>> getTimesForDay(LocalDate date)
    {
        Map<LocalDateTime, Set<Pill>> daySchedule = new TreeMap<>();
        for(LocalDateTime dates :timeSchedule.keySet())
        {
            if(dates.toLocalDate().equals(date))
            {
                daySchedule.put(dates, timeSchedule.get(dates));
            }
        }
        return daySchedule;
    }

    public static boolean containsName(String pillName)
    {
        for(Pill pill: pillSet)
        {
            if (pill.getName().equals(pillName))
            {
                return true;
            }
        }
        return false;
    }

    public static String formattedShortTime(LocalTime time)
    {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
        return time.format(formatter);
    }

    public static String monthYearFromDate(LocalDate date)
    {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM yyyy");
        return date.format(formatter);
    }

    public static String monthDayFromDate(LocalDate date)
    {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM d");
        return date.format(formatter);
    }

    public static ArrayList<LocalDate> daysInMonthArray()
    {
        ArrayList<LocalDate> daysInMonthArray = new ArrayList<>();

        YearMonth yearMonth = YearMonth.from(selectedDate);
        int daysInMonth = yearMonth.lengthOfMonth();

        LocalDate prevMonth = selectedDate.minusMonths(1);
        LocalDate nextMonth = selectedDate.plusMonths(1);

        YearMonth prevYearMonth = YearMonth.from(prevMonth);
        int prevDaysInMonth = prevYearMonth.lengthOfMonth();

        LocalDate firstOfMonth = CalendarUtils.selectedDate.withDayOfMonth(1);
        int dayOfWeek = firstOfMonth.getDayOfWeek().getValue();

        for(int i = 1; i <= 42; i++)
        {
            if(i <= dayOfWeek)
                daysInMonthArray.add(LocalDate.of(prevMonth.getYear(),prevMonth.getMonth(),prevDaysInMonth + i - dayOfWeek));
            else if(i > daysInMonth + dayOfWeek)
                daysInMonthArray.add(LocalDate.of(nextMonth.getYear(),nextMonth.getMonth(),i - dayOfWeek - daysInMonth));
            else
                daysInMonthArray.add(LocalDate.of(selectedDate.getYear(),selectedDate.getMonth(),i - dayOfWeek));
        }
        return  daysInMonthArray;
    }

    public static ArrayList<LocalDate> daysInWeekArray(LocalDate selectedDate)
    {
        ArrayList<LocalDate> days = new ArrayList<>();
        LocalDate current = sundayForDate(selectedDate);
        LocalDate endDate = current.plusWeeks(1);

        while (current.isBefore(endDate))
        {
            days.add(current);
            current = current.plusDays(1);
        }
        return days;
    }

    private static LocalDate sundayForDate(LocalDate current)
    {
        LocalDate oneWeekAgo = current.minusWeeks(1);

        while (current.isAfter(oneWeekAgo))
        {
            if(current.getDayOfWeek() == DayOfWeek.SUNDAY)
                return current;

            current = current.minusDays(1);
        }

        return null;
    }


}
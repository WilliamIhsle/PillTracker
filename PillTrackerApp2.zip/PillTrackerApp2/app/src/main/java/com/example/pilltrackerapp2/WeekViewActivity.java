package com.example.pilltrackerapp2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationManagerCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import java.time.LocalDate;
import java.util.ArrayList;

import static com.example.pilltrackerapp2.CalendarUtils.daysInWeekArray;
import com.example.pilltrackerapp2.CalendarUtils.*;
import static com.example.pilltrackerapp2.CalendarUtils.monthYearFromDate;

public class WeekViewActivity extends AppCompatActivity implements CalendarAdapter.OnItemListener
{
    private TextView monthYearText;
    private RecyclerView calendarRecyclerView;
    private ListView eventListView;

    private Button deleteModeChange, deleteButton;

    public static boolean deleteMode = false;
    private static final String CHANNEL_ID = "my_channel";
    private static final int NOTIFICATION_ID = 1;

    private NotificationManager notificationManager;
    private TextView otherTV;

    private Button eventCellTV;

    private CalendarUtils calendarUtils;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        Log.i("helpa", "creation!");
        super.onCreate(savedInstanceState);
        Log.i("gelllo", "aaa");
        calendarUtils = new CalendarUtils(getApplicationContext());
        calendarUtils.load();
        Log.i("10/20", "load succuesful");
        setContentView(R.layout.activity_week_view);
        Log.i("gelllo", "aaa3");
        initWidgets();
        Log.i("gelllo", "aaa2");
        setWeekView();
        Log.i("gelllo", "aaa4");
        Log.i("gettt", "eventAccccdapt");
      //  notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
      //  createNotificationChannel();
    }

    public void showNotification(View view) {
        Log.i("notification", "showNotification");
        Intent intent = new Intent(this, WeekViewActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this,0,intent, PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = null;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Log.i("notification", ":OOOOo");
            builder = new Notification.Builder(this,CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_launcher_background)
                    .setContentTitle("Take somethin")
                    .setContentText("It is time to take it")
                    .setPriority(Notification.PRIORITY_HIGH)
                    .setContentIntent(pendingIntent)
                    .setAutoCancel(true);
        }
        Log.i("notification", "Boom");
        Notification notification;
        Log.i("notification", "b");
        notification = builder.build();
        Log.i("notification", "c");
        if(notification == null)
        {
            Log.i("notification", "null");
        }
        notificationManager.notify(NOTIFICATION_ID, notification);
        Log.i("notification", "BOOM2");
    }
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
        {
            CharSequence channelName = "PillTaker";
            String channelDescription = "Notifies when to take your pills";

            int importance = NotificationManager.IMPORTANCE_HIGH;

            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, channelName, importance);
            channel.setDescription(channelDescription);

            notificationManager.createNotificationChannel(channel);
        }
    }


    public void deleteAction(View view)
    {
        Log.i("aaaaaaa", "1");
        deleteMode = !deleteMode;
        reload();

    }

    public void reload() {
        // Create an Intent to restart the current activity
        Intent intent = getIntent();
        finish(); // Close the current activity
        startActivity(intent); // Start the activity again
    }

    private void initWidgets()
    {
        calendarRecyclerView = findViewById(R.id.calendarRecyclerView);
        monthYearText = findViewById(R.id.monthYearTV);
        eventListView = findViewById(R.id.eventListView);
        deleteModeChange = findViewById(R.id.deleteModeChange);
       // deleteButton = findViewById(R.id.deleteButton);
        // Inflate the other layout
        LayoutInflater inflater = getLayoutInflater();
        View otherLayout = inflater.inflate(R.layout.event_cell, null);

        // Find the button in the inflated layout
        eventCellTV = otherLayout.findViewById(R.id.eventCellTV);
        Log.d("ButtonStatus2", "Button: " + eventCellTV);
        otherTV = findViewById(R.id.otherTV);
    }

    private void setWeekView()
    {
        monthYearText.setText(monthYearFromDate(CalendarUtils.selectedDate));
        ArrayList<LocalDate> days = daysInWeekArray(CalendarUtils.selectedDate);

        CalendarAdapter calendarAdapter = new CalendarAdapter(days, this);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getApplicationContext(), 7);
        calendarRecyclerView.setLayoutManager(layoutManager);
        calendarRecyclerView.setAdapter(calendarAdapter);
        setEventAdpater();
    }


    public void previousWeekAction(View view)
    {
        CalendarUtils.selectedDate = CalendarUtils.selectedDate.minusWeeks(1);
        setWeekView();
    }

    public void nextWeekAction(View view)
    {
        CalendarUtils.selectedDate = CalendarUtils.selectedDate.plusWeeks(1);
        setWeekView();
    }


    @Override
    public void onItemClick(int position, LocalDate date)
    {
        CalendarUtils.selectedDate = date;
        setWeekView();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        setEventAdpater();
    }

    private void setEventAdpater()
    {
        ArrayList<Pill> dailyPills = CalendarUtils.getPillsForDay(CalendarUtils.selectedDate);
        EventAdapter eventAdapter = new EventAdapter(getApplicationContext(), dailyPills);
        eventListView.setAdapter(eventAdapter);
    }

    public void newEventAction(View view)
    {
        startActivity(new Intent(this, EventEditActivity.class));
    }

    public void chatGPTAction(View view) {
        startActivity(new Intent(this, ChatGptMain.class));
    }
    // chatGPT STUFF

}